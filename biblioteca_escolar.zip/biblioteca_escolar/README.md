# Sistema de Biblioteca Escolar

Projeto acadêmico desenvolvido com **Python, Flask, MySQL, HTML, CSS e JavaScript**. O sistema permite gerenciar alunos, livros e empréstimos em uma interface web.

## 1. Funcionalidades

- Painel com quantidade de alunos, títulos, empréstimos ativos e empréstimos atrasados.
- Cadastro, consulta, edição e exclusão de alunos.
- Cadastro, consulta, edição e exclusão de livros.
- Registro de empréstimos com data prevista para devolução.
- Registro de devolução, com atualização automática da quantidade disponível.
- Pesquisa de livros, alunos e empréstimos na tela.
- Validações para evitar e-mail/ISBN duplicado, empréstimo sem estoque e exclusão de registros que já possuam histórico.

## 2. Tecnologias e organização

- **Front-end:** HTML5, CSS3 e JavaScript puro.
- **Back-end:** Python com Flask e rotas REST que recebem e retornam JSON.
- **Banco de dados:** MySQL/MariaDB, compatível com o MySQL incluído no XAMPP.
- **Integração:** JavaScript `fetch()` consome as rotas Flask.
- **Organização:** classes de modelo, DAOs para acesso ao banco e rotas separadas por recurso.

```text
biblioteca_escolar/
├── app.py
├── config.py
├── requirements.txt
├── .env.example
├── database/
│   ├── connection.py
│   ├── schema.sql
│   └── dados_exemplo.sql
├── models/
│   ├── aluno.py
│   ├── livro.py
│   └── emprestimo.py
├── dao/
│   ├── aluno_dao.py
│   ├── livro_dao.py
│   ├── emprestimo_dao.py
│   └── dashboard_dao.py
├── routes/
│   ├── alunos.py
│   ├── livros.py
│   ├── emprestimos.py
│   └── dashboard.py
├── templates/
│   └── index.html
├── static/
│   ├── css/style.css
│   └── js/app.js
└── docs/diagrama_uml.md
```

## 3. Como preparar o banco no XAMPP

1. Abra o **XAMPP Control Panel** e inicie o serviço **MySQL**. O Apache não é necessário para executar o Flask.
2. Abra `http://localhost/phpmyadmin` no navegador.
3. Entre na aba **Importar**, selecione `database/schema.sql` e execute. O script cria o banco `biblioteca_escolar` e as três tabelas.
4. Opcional: para preencher o sistema com exemplos de alunos e livros, importe também `database/dados_exemplo.sql`.

> Configuração padrão considerada: MySQL em `localhost:3306`, usuário `root`, senha vazia. Se seu XAMPP usa outra senha ou porta, ajuste o arquivo `.env` conforme a próxima seção.

## 4. Como executar no VS Code (Windows)

Tenha **Python 3.10 ou superior** instalado. Abra a pasta `biblioteca_escolar` no VS Code e use o terminal integrado.

```powershell
# Criar ambiente virtual
python -m venv .venv

# Ativar ambiente virtual no PowerShell
.\.venv\Scripts\Activate.ps1

# Instalar as bibliotecas
pip install -r requirements.txt

# Criar o arquivo de configuração local
Copy-Item .env.example .env

# Iniciar o servidor Flask
python app.py
```

Se o PowerShell bloquear a ativação do ambiente, você pode abrir o terminal **Prompt de Comando (cmd)** e executar:

```bat
.venv\Scripts\activate.bat
pip install -r requirements.txt
python app.py
```

Depois, acesse **http://127.0.0.1:5000** no navegador. Mantenha o terminal aberto enquanto utiliza o sistema.

### Configuração do banco

Edite o arquivo `.env` criado a partir de `.env.example`:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=biblioteca_escolar
FLASK_DEBUG=1
```

Não envie seu arquivo `.env` com senhas para outras pessoas. O `.env.example` pode ser compartilhado.

## 5. Rotas da API

| Método | Rota | Função |
|---|---|---|
| GET | `/api/health` | Verificar se o Flask está ativo |
| GET | `/api/dashboard` | Consultar indicadores do painel |
| GET / POST | `/api/alunos` | Listar ou cadastrar alunos |
| PUT / DELETE | `/api/alunos/<id>` | Editar ou excluir aluno |
| GET / POST | `/api/livros` | Listar ou cadastrar livros |
| PUT / DELETE | `/api/livros/<id>` | Editar ou excluir livro |
| GET / POST | `/api/emprestimos` | Listar ou registrar empréstimos |
| PATCH | `/api/emprestimos/<id>/devolver` | Registrar devolução |

As rotas retornam dados em JSON. As operações SQL estão nas classes DAO, e não diretamente nas funções das rotas.

## 6. Fluxo de funcionamento

1. O usuário realiza uma ação na página HTML.
2. O JavaScript captura os dados e envia uma requisição `fetch()` para a rota Flask.
3. A rota valida os dados recebidos e chama o DAO correspondente.
4. O DAO executa o comando SQL no MySQL e devolve o resultado.
5. A rota retorna uma resposta JSON, e o JavaScript atualiza a tela.

## 7. Testes recomendados para a apresentação

1. Cadastre um aluno e um livro.
2. Registre um empréstimo para esse aluno.
3. Mostre que a quantidade disponível do livro diminuiu.
4. Tente fazer outro empréstimo quando não houver exemplares disponíveis para demonstrar a validação.
5. Registre a devolução e mostre que a quantidade disponível aumentou.
6. Consulte os indicadores do painel e o histórico de empréstimos.

## 8. Observações

- Este é um projeto acadêmico local, sem autenticação de usuários.
- O sistema foi preparado para rodar com Flask e MySQL/MariaDB. O XAMPP é utilizado para iniciar o serviço de banco de dados; quem entrega as páginas e a API é o Flask.
- Para visualizar o diagrama UML, abra `docs/diagrama_uml.md` em um visualizador compatível com Mermaid ou use o código Mermaid em um editor de diagramas.
