from database.connection import get_connection

class DashboardDAO:
    def obter_resumo(self):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT COUNT(*) AS total FROM alunos")
            alunos = cursor.fetchone()["total"]
            cursor.execute("SELECT COUNT(*) AS total FROM livros")
            titulos = cursor.fetchone()["total"]
            cursor.execute("SELECT COALESCE(SUM(quantidade_total), 0) AS total FROM livros")
            exemplares = cursor.fetchone()["total"]
            cursor.execute("SELECT COUNT(*) AS total FROM emprestimos WHERE status='ATIVO'")
            ativos = cursor.fetchone()["total"]
            cursor.execute("SELECT COUNT(*) AS total FROM emprestimos WHERE status='ATIVO' AND data_devolucao_prevista < CURDATE()")
            atrasados = cursor.fetchone()["total"]
            return {"alunos": alunos, "titulos": titulos, "exemplares": exemplares,
                    "emprestimos_ativos": ativos, "atrasados": atrasados}
        finally:
            conn.close()
