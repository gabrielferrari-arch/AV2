from database.connection import get_connection
from models.livro import Livro

class LivroDAO:
    def listar(self):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""SELECT id, titulo, autor, isbn, categoria, ano_publicacao,
                              quantidade_total, quantidade_disponivel
                              FROM livros ORDER BY titulo""")
            return [Livro(**row).to_dict() for row in cursor.fetchall()]
        finally:
            conn.close()

    def buscar_por_id(self, livro_id):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""SELECT id, titulo, autor, isbn, categoria, ano_publicacao,
                              quantidade_total, quantidade_disponivel
                              FROM livros WHERE id=%s""", (livro_id,))
            row = cursor.fetchone()
            return Livro(**row).to_dict() if row else None
        finally:
            conn.close()

    def criar(self, dados):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("""INSERT INTO livros
                (titulo, autor, isbn, categoria, ano_publicacao, quantidade_total, quantidade_disponivel)
                VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                (dados["titulo"], dados["autor"], dados["isbn"], dados["categoria"],
                 dados["ano_publicacao"], dados["quantidade_total"], dados["quantidade_total"]))
            livro_id = cursor.lastrowid
            conn.commit()
            return self.buscar_por_id(livro_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def atualizar(self, livro_id, dados):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT quantidade_total, quantidade_disponivel FROM livros WHERE id=%s FOR UPDATE", (livro_id,))
            atual = cursor.fetchone()
            if not atual:
                return False, "Livro não encontrado."
            emprestados = atual["quantidade_total"] - atual["quantidade_disponivel"]
            if dados["quantidade_total"] < emprestados:
                return False, f"Existem {emprestados} exemplar(es) emprestado(s). A quantidade total não pode ser menor que isso."
            nova_disponibilidade = dados["quantidade_total"] - emprestados
            cursor.execute("""UPDATE livros SET titulo=%s, autor=%s, isbn=%s, categoria=%s,
                ano_publicacao=%s, quantidade_total=%s, quantidade_disponivel=%s WHERE id=%s""",
                (dados["titulo"], dados["autor"], dados["isbn"], dados["categoria"],
                 dados["ano_publicacao"], dados["quantidade_total"], nova_disponibilidade, livro_id))
            conn.commit()
            return True, None
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def excluir(self, livro_id):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM livros WHERE id=%s", (livro_id,))
            conn.commit()
            return cursor.rowcount > 0
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
