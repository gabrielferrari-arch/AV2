from database.connection import get_connection
from models.aluno import Aluno

class AlunoDAO:
    def listar(self):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT id, nome, email, turma FROM alunos ORDER BY nome")
            return [Aluno(**row).to_dict() for row in cursor.fetchall()]
        finally:
            conn.close()

    def buscar_por_id(self, aluno_id):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT id, nome, email, turma FROM alunos WHERE id = %s", (aluno_id,))
            row = cursor.fetchone()
            return Aluno(**row).to_dict() if row else None
        finally:
            conn.close()

    def criar(self, nome, email, turma):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO alunos (nome, email, turma) VALUES (%s, %s, %s)",
                (nome, email, turma),
            )
            aluno_id = cursor.lastrowid
            conn.commit()
            return self.buscar_por_id(aluno_id)
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def atualizar(self, aluno_id, nome, email, turma):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM alunos WHERE id=%s", (aluno_id,))
            if not cursor.fetchone():
                return False
            cursor.execute(
                "UPDATE alunos SET nome=%s, email=%s, turma=%s WHERE id=%s",
                (nome, email, turma, aluno_id),
            )
            conn.commit()
            return True
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def excluir(self, aluno_id):
        conn = get_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM alunos WHERE id=%s", (aluno_id,))
            conn.commit()
            return cursor.rowcount > 0
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
