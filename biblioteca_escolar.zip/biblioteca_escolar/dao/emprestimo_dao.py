from database.connection import get_connection
from models.emprestimo import Emprestimo

class EmprestimoDAO:
    def listar(self):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("""SELECT e.id, e.aluno_id, e.livro_id, a.nome AS aluno_nome,
                l.titulo AS livro_titulo, e.data_emprestimo, e.data_devolucao_prevista,
                e.data_devolucao, e.status
                FROM emprestimos e
                INNER JOIN alunos a ON a.id=e.aluno_id
                INNER JOIN livros l ON l.id=e.livro_id
                ORDER BY e.id DESC""")
            return [Emprestimo(**row).to_dict() for row in cursor.fetchall()]
        finally:
            conn.close()

    def criar(self, aluno_id, livro_id, data_prevista):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT quantidade_disponivel FROM livros WHERE id=%s FOR UPDATE", (livro_id,))
            livro = cursor.fetchone()
            if not livro:
                raise ValueError("Livro não encontrado.")
            if livro["quantidade_disponivel"] < 1:
                raise ValueError("Não há exemplares disponíveis desse livro.")
            cursor.execute("SELECT id FROM alunos WHERE id=%s", (aluno_id,))
            if not cursor.fetchone():
                raise ValueError("Aluno não encontrado.")
            cursor.execute("""INSERT INTO emprestimos
                (aluno_id, livro_id, data_emprestimo, data_devolucao_prevista, status)
                VALUES (%s, %s, CURDATE(), %s, 'ATIVO')""", (aluno_id, livro_id, data_prevista))
            emprestimo_id = cursor.lastrowid
            cursor.execute("UPDATE livros SET quantidade_disponivel=quantidade_disponivel-1 WHERE id=%s", (livro_id,))
            conn.commit()
            return emprestimo_id
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def devolver(self, emprestimo_id):
        conn = get_connection()
        try:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT livro_id, status FROM emprestimos WHERE id=%s FOR UPDATE", (emprestimo_id,))
            emprestimo = cursor.fetchone()
            if not emprestimo:
                return False, "Empréstimo não encontrado."
            if emprestimo["status"] == "DEVOLVIDO":
                return False, "Esse empréstimo já foi devolvido."
            cursor.execute("UPDATE emprestimos SET status='DEVOLVIDO', data_devolucao=CURDATE() WHERE id=%s", (emprestimo_id,))
            cursor.execute("UPDATE livros SET quantidade_disponivel=quantidade_disponivel+1 WHERE id=%s", (emprestimo["livro_id"],))
            conn.commit()
            return True, None
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
