# Modelagem UML — Biblioteca Escolar

## Diagrama de classes

```mermaid
classDiagram
    class Aluno {
        +int id
        +string nome
        +string email
        +string turma
        +to_dict() dict
    }
    class Livro {
        +int id
        +string titulo
        +string autor
        +string isbn
        +string categoria
        +int ano_publicacao
        +int quantidade_total
        +int quantidade_disponivel
        +to_dict() dict
    }
    class Emprestimo {
        +int id
        +int aluno_id
        +int livro_id
        +string aluno_nome
        +string livro_titulo
        +date data_emprestimo
        +date data_devolucao_prevista
        +date data_devolucao
        +string status
        +to_dict() dict
    }
    class AlunoDAO {
        +listar() list
        +buscar_por_id(id) dict
        +criar(nome,email,turma) dict
        +atualizar(id,nome,email,turma) bool
        +excluir(id) bool
    }
    class LivroDAO {
        +listar() list
        +buscar_por_id(id) dict
        +criar(dados) dict
        +atualizar(id,dados) bool
        +excluir(id) bool
    }
    class EmprestimoDAO {
        +listar() list
        +criar(aluno_id,livro_id,data_prevista) int
        +devolver(id) bool
    }
    Aluno "1" --> "0..*" Emprestimo : realiza
    Livro "1" --> "0..*" Emprestimo : aparece em
    AlunoDAO ..> Aluno : manipula
    LivroDAO ..> Livro : manipula
    EmprestimoDAO ..> Emprestimo : manipula
```

## Relacionamentos do banco de dados

- Um aluno pode possuir vários registros de empréstimo.
- Um livro pode aparecer em vários registros de empréstimo ao longo do tempo.
- Cada empréstimo pertence a exatamente um aluno e a exatamente um livro.
- As chaves estrangeiras impedem apagar alunos ou livros que já tenham empréstimos registrados.
- A quantidade disponível do livro diminui ao registrar um empréstimo e aumenta ao registrar uma devolução.
