from dataclasses import dataclass

@dataclass
class Emprestimo:
    id: int
    aluno_id: int
    livro_id: int
    aluno_nome: str
    livro_titulo: str
    data_emprestimo: str
    data_devolucao_prevista: str
    data_devolucao: str | None
    status: str

    def to_dict(self):
        return {
            "id": self.id,
            "aluno_id": self.aluno_id,
            "livro_id": self.livro_id,
            "aluno_nome": self.aluno_nome,
            "livro_titulo": self.livro_titulo,
            "data_emprestimo": str(self.data_emprestimo),
            "data_devolucao_prevista": str(self.data_devolucao_prevista),
            "data_devolucao": str(self.data_devolucao) if self.data_devolucao else None,
            "status": self.status,
        }
