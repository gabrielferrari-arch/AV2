from dataclasses import dataclass

@dataclass
class Livro:
    id: int | None
    titulo: str
    autor: str
    isbn: str | None
    categoria: str
    ano_publicacao: int | None
    quantidade_total: int
    quantidade_disponivel: int

    def to_dict(self):
        return {
            "id": self.id,
            "titulo": self.titulo,
            "autor": self.autor,
            "isbn": self.isbn,
            "categoria": self.categoria,
            "ano_publicacao": self.ano_publicacao,
            "quantidade_total": self.quantidade_total,
            "quantidade_disponivel": self.quantidade_disponivel,
        }
