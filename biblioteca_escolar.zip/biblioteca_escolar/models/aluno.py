from dataclasses import dataclass

@dataclass
class Aluno:
    id: int | None
    nome: str
    email: str
    turma: str

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "email": self.email,
            "turma": self.turma,
        }
