import mysql.connector
from config import Config


def get_connection():
    """Abre uma conexao com o MySQL configurado no arquivo .env."""
    return mysql.connector.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        database=Config.DB_NAME,
        charset="utf8mb4",
        autocommit=False,
    )
