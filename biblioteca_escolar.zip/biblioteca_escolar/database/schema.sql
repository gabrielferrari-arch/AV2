-- Banco de dados do Sistema de Biblioteca Escolar
CREATE DATABASE IF NOT EXISTS biblioteca_escolar
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biblioteca_escolar;

CREATE TABLE IF NOT EXISTS alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    turma VARCHAR(30) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS livros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(180) NOT NULL,
    autor VARCHAR(120) NOT NULL,
    isbn VARCHAR(20) NULL UNIQUE,
    categoria VARCHAR(80) NOT NULL,
    ano_publicacao SMALLINT NULL,
    quantidade_total INT NOT NULL DEFAULT 1,
    quantidade_disponivel INT NOT NULL DEFAULT 1,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_livros_quantidades CHECK (
        quantidade_total >= 0 AND quantidade_disponivel >= 0
        AND quantidade_disponivel <= quantidade_total
    )
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS emprestimos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    aluno_id INT NOT NULL,
    livro_id INT NOT NULL,
    data_emprestimo DATE NOT NULL,
    data_devolucao_prevista DATE NOT NULL,
    data_devolucao DATE NULL,
    status ENUM('ATIVO', 'DEVOLVIDO') NOT NULL DEFAULT 'ATIVO',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_emprestimos_alunos FOREIGN KEY (aluno_id)
        REFERENCES alunos(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_emprestimos_livros FOREIGN KEY (livro_id)
        REFERENCES livros(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    INDEX idx_emprestimos_status (status),
    INDEX idx_emprestimos_aluno (aluno_id),
    INDEX idx_emprestimos_livro (livro_id)
) ENGINE=InnoDB;
