-- OPCIONAL: execute depois de importar schema.sql para preencher o sistema com dados de teste.
USE biblioteca_escolar;

INSERT IGNORE INTO alunos (nome, email, turma) VALUES
('Ana Souza', 'ana.souza@escola.com', '2º Técnico A'),
('Bruno Lima', 'bruno.lima@escola.com', '2º Técnico B'),
('Carla Mendes', 'carla.mendes@escola.com', '2º Técnico A'),
('Daniel Alves', 'daniel.alves@escola.com', '1º Técnico C');

INSERT IGNORE INTO livros (titulo, autor, isbn, categoria, ano_publicacao, quantidade_total, quantidade_disponivel) VALUES
('O Pequeno Príncipe', 'Antoine de Saint-Exupéry', '978-8522031445', 'Literatura', 1943, 4, 4),
('Dom Casmurro', 'Machado de Assis', '978-8535910663', 'Literatura brasileira', 1899, 3, 3),
('A Revolução dos Bichos', 'George Orwell', '978-8535909555', 'Ficção', 1945, 2, 2),
('O Guia do Mochileiro das Galáxias', 'Douglas Adams', '978-8599296943', 'Ficção científica', 1979, 2, 2),
('Quarto de Despejo', 'Carolina Maria de Jesus', '978-8508171279', 'Literatura brasileira', 1960, 3, 3);
