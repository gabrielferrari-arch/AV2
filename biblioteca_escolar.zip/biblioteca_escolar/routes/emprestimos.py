from datetime import date, datetime
from flask import Blueprint, jsonify, request
from mysql.connector import Error
from dao.emprestimo_dao import EmprestimoDAO

bp_emprestimos = Blueprint("emprestimos", __name__, url_prefix="/api/emprestimos")
dao = EmprestimoDAO()

@bp_emprestimos.get("")
def listar_emprestimos():
    try:
        return jsonify(dao.listar())
    except Error:
        return jsonify({"erro": "Não foi possível consultar os empréstimos."}), 500

@bp_emprestimos.post("")
def criar_emprestimo():
    dados = request.get_json(silent=True) or {}
    try:
        aluno_id = int(dados.get("aluno_id"))
        livro_id = int(dados.get("livro_id"))
        data_prevista = str(dados.get("data_devolucao_prevista", ""))
        data_obj = datetime.strptime(data_prevista, "%Y-%m-%d").date()
        if data_obj < date.today():
            raise ValueError("A data prevista de devolução não pode estar no passado.")
        if aluno_id < 1 or livro_id < 1:
            raise ValueError("Selecione um aluno e um livro.")
        novo_id = dao.criar(aluno_id, livro_id, data_prevista)
        return jsonify({"id": novo_id, "mensagem": "Empréstimo registrado com sucesso."}), 201
    except (TypeError, ValueError) as erro:
        mensagem = str(erro) if str(erro) else "Informe aluno, livro e data prevista de devolução."
        return jsonify({"erro": mensagem}), 400
    except Error:
        return jsonify({"erro": "Erro ao registrar o empréstimo no banco de dados."}), 500

@bp_emprestimos.patch("/<int:emprestimo_id>/devolver")
def devolver_emprestimo(emprestimo_id):
    try:
        sucesso, mensagem = dao.devolver(emprestimo_id)
        if not sucesso:
            return jsonify({"erro": mensagem}), 404 if mensagem == "Empréstimo não encontrado." else 409
        return jsonify({"mensagem": "Devolução registrada com sucesso."})
    except Error:
        return jsonify({"erro": "Erro ao registrar a devolução."}), 500
