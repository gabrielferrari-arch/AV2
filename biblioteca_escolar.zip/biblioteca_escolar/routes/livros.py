from flask import Blueprint, jsonify, request
from mysql.connector import IntegrityError, Error
from dao.livro_dao import LivroDAO

bp_livros = Blueprint("livros", __name__, url_prefix="/api/livros")
dao = LivroDAO()


def validar_livro(dados):
    titulo = str(dados.get("titulo", "")).strip()
    autor = str(dados.get("autor", "")).strip()
    categoria = str(dados.get("categoria", "")).strip()
    isbn = str(dados.get("isbn", "")).strip() or None
    if not titulo or not autor or not categoria:
        raise ValueError("Preencha título, autor e categoria.")
    try:
        quantidade = int(dados.get("quantidade_total", 1))
        ano_raw = dados.get("ano_publicacao")
        ano = int(ano_raw) if ano_raw not in (None, "") else None
    except (TypeError, ValueError):
        raise ValueError("Ano e quantidade devem ser números válidos.")
    if quantidade < 0:
        raise ValueError("A quantidade não pode ser negativa.")
    if ano is not None and not (1000 <= ano <= 2100):
        raise ValueError("Informe um ano de publicação válido.")
    return {"titulo": titulo, "autor": autor, "categoria": categoria,
            "isbn": isbn, "ano_publicacao": ano, "quantidade_total": quantidade}

@bp_livros.get("")
def listar_livros():
    try:
        return jsonify(dao.listar())
    except Error:
        return jsonify({"erro": "Não foi possível consultar os livros."}), 500

@bp_livros.post("")
def criar_livro():
    try:
        dados = validar_livro(request.get_json(silent=True) or {})
        return jsonify(dao.criar(dados)), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400
    except IntegrityError:
        return jsonify({"erro": "Já existe um livro cadastrado com esse ISBN."}), 409
    except Error:
        return jsonify({"erro": "Erro ao salvar o livro no banco de dados."}), 500

@bp_livros.put("/<int:livro_id>")
def atualizar_livro(livro_id):
    try:
        dados = validar_livro(request.get_json(silent=True) or {})
        atualizado, mensagem = dao.atualizar(livro_id, dados)
        if not atualizado:
            return jsonify({"erro": mensagem or "Livro não encontrado."}), 404 if mensagem == "Livro não encontrado." else 400
        return jsonify(dao.buscar_por_id(livro_id))
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400
    except IntegrityError:
        return jsonify({"erro": "Já existe um livro cadastrado com esse ISBN."}), 409
    except Error:
        return jsonify({"erro": "Erro ao atualizar o livro."}), 500

@bp_livros.delete("/<int:livro_id>")
def excluir_livro(livro_id):
    try:
        if not dao.excluir(livro_id):
            return jsonify({"erro": "Livro não encontrado."}), 404
        return jsonify({"mensagem": "Livro excluído com sucesso."})
    except IntegrityError:
        return jsonify({"erro": "Este livro possui empréstimos registrados e não pode ser excluído."}), 409
    except Error:
        return jsonify({"erro": "Erro ao excluir o livro."}), 500
