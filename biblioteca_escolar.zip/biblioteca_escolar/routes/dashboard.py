from flask import Blueprint, jsonify
from mysql.connector import Error
from dao.dashboard_dao import DashboardDAO

bp_dashboard = Blueprint("dashboard", __name__, url_prefix="/api/dashboard")
dao = DashboardDAO()

@bp_dashboard.get("")
def resumo():
    try:
        return jsonify(dao.obter_resumo())
    except Error:
        return jsonify({"erro": "Não foi possível carregar o resumo da biblioteca."}), 500
