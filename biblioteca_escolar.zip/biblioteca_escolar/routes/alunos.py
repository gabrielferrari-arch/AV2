from flask import Blueprint, jsonify, request
from mysql.connector import IntegrityError, Error
from dao.aluno_dao import AlunoDAO

bp_alunos = Blueprint("alunos", __name__, url_prefix="/api/alunos")
dao = AlunoDAO()


def validar_aluno(dados):
    nome = str(dados.get("nome", "")).strip()
    email = str(dados.get("email", "")).strip().lower()
    turma = str(dados.get("turma", "")).strip()
    if not nome or not email or not turma:
        raise ValueError("Preencha nome, e-mail e turma.")
    if "@" not in email or "." not in email.split("@")[-1]:
        raise ValueError("Informe um e-mail válido.")
    return nome, email, turma

@bp_alunos.get("")
def listar_alunos():
    try:
        return jsonify(dao.listar())
    except Error:
        return jsonify({"erro": "Não foi possível consultar os alunos."}), 500

@bp_alunos.post("")
def criar_aluno():
    try:
        nome, email, turma = validar_aluno(request.get_json(silent=True) or {})
        aluno = dao.criar(nome, email, turma)
        return jsonify(aluno), 201
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400
    except IntegrityError:
        return jsonify({"erro": "Já existe um aluno cadastrado com esse e-mail."}), 409
    except Error:
        return jsonify({"erro": "Erro ao salvar o aluno no banco de dados."}), 500

@bp_alunos.put("/<int:aluno_id>")
def atualizar_aluno(aluno_id):
    try:
        nome, email, turma = validar_aluno(request.get_json(silent=True) or {})
        if not dao.atualizar(aluno_id, nome, email, turma):
            return jsonify({"erro": "Aluno não encontrado."}), 404
        return jsonify(dao.buscar_por_id(aluno_id))
    except ValueError as erro:
        return jsonify({"erro": str(erro)}), 400
    except IntegrityError:
        return jsonify({"erro": "Já existe um aluno cadastrado com esse e-mail."}), 409
    except Error:
        return jsonify({"erro": "Erro ao atualizar o aluno."}), 500

@bp_alunos.delete("/<int:aluno_id>")
def excluir_aluno(aluno_id):
    try:
        if not dao.excluir(aluno_id):
            return jsonify({"erro": "Aluno não encontrado."}), 404
        return jsonify({"mensagem": "Aluno excluído com sucesso."})
    except IntegrityError:
        return jsonify({"erro": "Este aluno possui empréstimos registrados e não pode ser excluído."}), 409
    except Error:
        return jsonify({"erro": "Erro ao excluir o aluno."}), 500
