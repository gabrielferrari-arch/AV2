@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Ambiente virtual nao encontrado.
  echo Primeiro siga os passos de instalacao do README.md.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python app.py
pause
