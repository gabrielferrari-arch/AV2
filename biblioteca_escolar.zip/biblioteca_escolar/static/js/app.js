const API = "";
const state = { page: "inicio", alunos: [], livros: [], emprestimos: [] };
let modalSubmitHandler = null;
let toastTimer = null;

const $ = (selector) => document.querySelector(selector);
const pageContent = $("#pageContent");

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

async function api(path, options = {}) {
  const config = { ...options, headers: { "Content-Type": "application/json", ...(options.headers || {}) } };
  const response = await fetch(`${API}${path}`, config);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.erro || "Não foi possível concluir a operação.");
  return data;
}

function showToast(message, isError = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}

function formatDate(value) {
  if (!value) return "—";
  const [year, month, day] = String(value).slice(0, 10).split("-");
  return `${day}/${month}/${year}`;
}

function todayISO() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

function setPage(page) {
  state.page = page;
  const titles = { inicio: "Visão geral", livros: "Livros", alunos: "Alunos", emprestimos: "Empréstimos" };
  $("#currentSection").textContent = titles[page] || "Biblioteca";
  document.querySelectorAll(".nav-link").forEach((button) => button.classList.toggle("active", button.dataset.page === page));
  $("#sidebar").classList.remove("open");
  renderPage();
}

async function loadAll() {
  const [alunos, livros, emprestimos] = await Promise.all([
    api("/api/alunos"), api("/api/livros"), api("/api/emprestimos")
  ]);
  state.alunos = alunos;
  state.livros = livros;
  state.emprestimos = emprestimos;
}

async function renderPage() {
  pageContent.innerHTML = '<div class="loading-state">Carregando dados da biblioteca...</div>';
  try {
    if (state.page === "inicio") await renderDashboard();
    if (state.page === "livros") { state.livros = await api("/api/livros"); renderBooks(); }
    if (state.page === "alunos") { state.alunos = await api("/api/alunos"); renderStudents(); }
    if (state.page === "emprestimos") {
      const [emprestimos, alunos, livros] = await Promise.all([api("/api/emprestimos"), api("/api/alunos"), api("/api/livros")]);
      state.emprestimos = emprestimos; state.alunos = alunos; state.livros = livros; renderLoans();
    }
  } catch (error) {
    pageContent.innerHTML = `<div class="panel empty-state"><strong>Não foi possível carregar os dados.</strong>${escapeHTML(error.message)}<br><br>Confira se o MySQL do XAMPP está ligado e se o Flask está conectado ao banco.</div>`;
  }
}

function pageHeading(eyebrow, title, description, buttonText = "", buttonAction = "") {
  return `<div class="page-heading"><div><div class="eyebrow">${eyebrow}</div><h1>${title}</h1><p class="page-description">${description}</p></div>${buttonText ? `<button class="button button-primary" data-action="${buttonAction}"><span>＋</span>${buttonText}</button>` : ""}</div>`;
}

async function renderDashboard() {
  const [summary, loans] = await Promise.all([api("/api/dashboard"), api("/api/emprestimos")]);
  state.emprestimos = loans;
  const activeLoans = loans.filter((loan) => loan.status === "ATIVO").slice(0, 5);
  const cards = [
    ["Alunos cadastrados", summary.alunos, "♙", "success", "Pessoas registradas"],
    ["Títulos no acervo", summary.titulos, "▤", "", `${summary.exemplares} exemplares no total`],
    ["Empréstimos ativos", summary.emprestimos_ativos, "⇄", "success", "Livros fora da biblioteca"],
    ["Em atraso", summary.atrasados, "◷", "warning", "Precisam de atenção"]
  ];
  pageContent.innerHTML = `${pageHeading("PAINEL DE CONTROLE", "Bem-vindo à biblioteca", "Acompanhe os livros, alunos e empréstimos da biblioteca escolar.")}
    <div class="stats-grid">${cards.map(([label, value, icon, style, note]) => `<article class="stat-card ${style}"><div class="stat-top"><span>${label}</span><span class="stat-icon">${icon}</span></div><div class="stat-value">${value}</div><div class="stat-note">${note}</div></article>`).join("")}</div>
    <div class="content-grid">
      <section class="panel"><div class="panel-header"><div><h2>Empréstimos em andamento</h2><p class="panel-subtitle">Acompanhe os registros mais recentes</p></div><button class="text-button" data-page="emprestimos">Ver todos →</button></div>
        <div class="table-wrap"><table><thead><tr><th>Aluno</th><th>Livro</th><th>Devolução prevista</th><th>Status</th></tr></thead><tbody>${activeLoans.length ? activeLoans.map((loan) => loanRow(loan, false)).join("") : '<tr><td class="empty-cell" colspan="4">Nenhum empréstimo ativo no momento.</td></tr>'}</tbody></table></div></section>
      <section class="panel quick-panel"><h2>Ações rápidas</h2><p>Atalhos para as tarefas mais comuns.</p>
        <button class="quick-action" data-action="new-book"><span class="quick-action-icon">＋</span><span><strong>Cadastrar livro</strong><small>Adicionar um título ao acervo</small></span></button>
        <button class="quick-action" data-action="new-student"><span class="quick-action-icon">♙</span><span><strong>Cadastrar aluno</strong><small>Registrar um novo leitor</small></span></button>
        <button class="quick-action" data-action="new-loan"><span class="quick-action-icon">⇄</span><span><strong>Novo empréstimo</strong><small>Entregar um livro a um aluno</small></span></button>
      </section>
    </div>`;
}

function loanRow(loan, showActions = true) {
  const late = loan.status === "ATIVO" && loan.data_devolucao_prevista < todayISO();
  const status = loan.status === "DEVOLVIDO" ? '<span class="status returned">Devolvido</span>' : late ? '<span class="status late">Em atraso</span>' : '<span class="status active">Em andamento</span>';
  return `<tr><td><strong>${escapeHTML(loan.aluno_nome)}</strong></td><td>${escapeHTML(loan.livro_titulo)}</td><td>${formatDate(loan.data_devolucao_prevista)}</td><td>${status}</td>${showActions ? `<td>${loan.status === "ATIVO" ? `<button class="action-button" data-action="return-loan" data-id="${loan.id}">Registrar devolução</button>` : "—"}</td>` : ""}</tr>`;
}

function renderBooks() {
  pageContent.innerHTML = `${pageHeading("ACERVO", "Livros", "Gerencie os títulos e acompanhe a quantidade de exemplares disponíveis.", "Adicionar livro", "new-book")}
    <div class="toolbar"><label class="search-box"><span>⌕</span><input id="tableSearch" type="search" placeholder="Buscar por título, autor ou categoria..."></label><span class="table-count">${state.livros.length} registro(s)</span></div>
    <section class="panel table-panel"><div class="table-wrap"><table id="dataTable"><thead><tr><th>Livro</th><th>Autor</th><th>Categoria</th><th>Ano</th><th>Disponíveis</th><th>Ações</th></tr></thead><tbody>${state.livros.length ? state.livros.map((book) => `<tr data-search="${escapeHTML(`${book.titulo} ${book.autor} ${book.categoria}`.toLowerCase())}"><td><strong>${escapeHTML(book.titulo)}</strong><br><span style="color:#9aa5b4;font-size:9px">ISBN: ${escapeHTML(book.isbn || "Não informado")}</span></td><td>${escapeHTML(book.autor)}</td><td>${escapeHTML(book.categoria)}</td><td>${book.ano_publicacao || "—"}</td><td><span class="status ${book.quantidade_disponivel > 0 ? "active" : "late"}">${book.quantidade_disponivel} / ${book.quantidade_total}</span></td><td><div class="action-group"><button class="action-button" data-action="edit-book" data-id="${book.id}">Editar</button><button class="action-button danger" data-action="delete-book" data-id="${book.id}">Excluir</button></div></td></tr>`).join("") : '<tr><td colspan="6" class="empty-cell">Nenhum livro cadastrado. Use “Adicionar livro” para começar.</td></tr>'}</tbody></table></div></section>`;
  attachSearch();
}

function renderStudents() {
  pageContent.innerHTML = `${pageHeading("LEITORES", "Alunos", "Cadastre e mantenha os dados dos alunos que utilizam a biblioteca.", "Adicionar aluno", "new-student")}
    <div class="toolbar"><label class="search-box"><span>⌕</span><input id="tableSearch" type="search" placeholder="Buscar por nome, e-mail ou turma..."></label><span class="table-count">${state.alunos.length} registro(s)</span></div>
    <section class="panel table-panel"><div class="table-wrap"><table id="dataTable"><thead><tr><th>Nome</th><th>E-mail</th><th>Turma</th><th>Ações</th></tr></thead><tbody>${state.alunos.length ? state.alunos.map((student) => `<tr data-search="${escapeHTML(`${student.nome} ${student.email} ${student.turma}`.toLowerCase())}"><td><strong>${escapeHTML(student.nome)}</strong></td><td>${escapeHTML(student.email)}</td><td>${escapeHTML(student.turma)}</td><td><div class="action-group"><button class="action-button" data-action="edit-student" data-id="${student.id}">Editar</button><button class="action-button danger" data-action="delete-student" data-id="${student.id}">Excluir</button></div></td></tr>`).join("") : '<tr><td colspan="4" class="empty-cell">Nenhum aluno cadastrado. Use “Adicionar aluno” para começar.</td></tr>'}</tbody></table></div></section>`;
  attachSearch();
}

function renderLoans() {
  pageContent.innerHTML = `${pageHeading("CIRCULAÇÃO", "Empréstimos", "Registre a retirada de livros e confirme as devoluções.", "Novo empréstimo", "new-loan")}
    <div class="toolbar"><label class="search-box"><span>⌕</span><input id="tableSearch" type="search" placeholder="Buscar por aluno ou livro..."></label><span class="table-count">${state.emprestimos.length} registro(s)</span></div>
    <section class="panel table-panel"><div class="table-wrap"><table id="dataTable"><thead><tr><th>Aluno</th><th>Livro</th><th>Retirada</th><th>Devolução prevista</th><th>Status</th><th>Ação</th></tr></thead><tbody>${state.emprestimos.length ? state.emprestimos.map((loan) => `<tr data-search="${escapeHTML(`${loan.aluno_nome} ${loan.livro_titulo}`.toLowerCase())}"><td><strong>${escapeHTML(loan.aluno_nome)}</strong></td><td>${escapeHTML(loan.livro_titulo)}</td><td>${formatDate(loan.data_emprestimo)}</td><td>${formatDate(loan.data_devolucao_prevista)}</td><td>${loan.status === "DEVOLVIDO" ? '<span class="status returned">Devolvido</span>' : loan.data_devolucao_prevista < todayISO() ? '<span class="status late">Em atraso</span>' : '<span class="status active">Em andamento</span>'}</td><td>${loan.status === "ATIVO" ? `<button class="action-button" data-action="return-loan" data-id="${loan.id}">Registrar devolução</button>` : "—"}</td></tr>`).join("") : '<tr><td colspan="6" class="empty-cell">Nenhum empréstimo registrado ainda.</td></tr>'}</tbody></table></div></section>`;
  attachSearch();
}

function attachSearch() {
  const input = $("#tableSearch");
  if (!input) return;
  input.addEventListener("input", () => {
    const term = input.value.trim().toLowerCase();
    document.querySelectorAll("#dataTable tbody tr[data-search]").forEach((row) => {
      row.hidden = !row.dataset.search.includes(term);
    });
  });
}

function showModal({ eyebrow = "CADASTRO", title, fields, submitText = "Salvar registro", onSubmit }) {
  $("#modalEyebrow").textContent = eyebrow;
  $("#modalTitle").textContent = title;
  $("#saveButton").textContent = submitText;
  $("#modalBody").innerHTML = `<div class="form-grid">${fields.map((field) => {
    const full = field.full ? "full" : "";
    const required = field.required ? "required" : "";
    const value = field.value ?? "";
    if (field.type === "select") {
      return `<div class="form-field ${full}"><label for="field_${field.name}">${field.label}</label><select id="field_${field.name}" name="${field.name}" ${required}><option value="">Selecione...</option>${field.options.map((option) => `<option value="${escapeHTML(option.value)}" ${String(option.value) === String(value) ? "selected" : ""}>${escapeHTML(option.label)}</option>`).join("")}</select></div>`;
    }
    return `<div class="form-field ${full}"><label for="field_${field.name}">${field.label}</label><input id="field_${field.name}" name="${field.name}" type="${field.type || "text"}" value="${escapeHTML(value)}" placeholder="${escapeHTML(field.placeholder || "")}" ${required} ${field.min !== undefined ? `min="${field.min}"` : ""} ${field.max !== undefined ? `max="${field.max}"` : ""} ${field.step ? `step="${field.step}"` : ""}></div>`;
  }).join("")}</div>`;
  modalSubmitHandler = onSubmit;
  $("#modalBackdrop").hidden = false;
  setTimeout(() => $("#modalBody input, #modalBody select")?.focus(), 50);
}

function closeModal() {
  $("#modalBackdrop").hidden = true;
  $("#modalForm").reset();
  modalSubmitHandler = null;
}

function openStudentModal(student = null) {
  showModal({
    eyebrow: "CADASTRO DE LEITOR", title: student ? "Editar aluno" : "Novo aluno",
    fields: [
      { name: "nome", label: "Nome completo", value: student?.nome || "", required: true, full: true, placeholder: "Ex.: Ana Souza" },
      { name: "email", label: "E-mail", type: "email", value: student?.email || "", required: true, full: true, placeholder: "aluno@escola.com" },
      { name: "turma", label: "Turma", value: student?.turma || "", required: true, placeholder: "Ex.: 2º Técnico A" }
    ],
    onSubmit: async (values) => {
      await api(student ? `/api/alunos/${student.id}` : "/api/alunos", { method: student ? "PUT" : "POST", body: JSON.stringify(values) });
      closeModal(); showToast(student ? "Aluno atualizado com sucesso." : "Aluno cadastrado com sucesso."); await renderPage();
    }
  });
}

function openBookModal(book = null) {
  showModal({
    eyebrow: "CADASTRO DO ACERVO", title: book ? "Editar livro" : "Adicionar livro",
    fields: [
      { name: "titulo", label: "Título do livro", value: book?.titulo || "", required: true, full: true },
      { name: "autor", label: "Autor", value: book?.autor || "", required: true },
      { name: "categoria", label: "Categoria", value: book?.categoria || "", required: true },
      { name: "isbn", label: "ISBN (opcional)", value: book?.isbn || "", full: true },
      { name: "ano_publicacao", label: "Ano de publicação", type: "number", value: book?.ano_publicacao || "", min: 1000, max: 2100 },
      { name: "quantidade_total", label: "Quantidade de exemplares", type: "number", value: book?.quantidade_total ?? 1, min: 0, required: true }
    ],
    onSubmit: async (values) => {
      values.quantidade_total = Number(values.quantidade_total);
      values.ano_publicacao = values.ano_publicacao ? Number(values.ano_publicacao) : null;
      await api(book ? `/api/livros/${book.id}` : "/api/livros", { method: book ? "PUT" : "POST", body: JSON.stringify(values) });
      closeModal(); showToast(book ? "Livro atualizado com sucesso." : "Livro cadastrado com sucesso."); await renderPage();
    }
  });
}

async function openLoanModal() {
  const [alunos, livros] = await Promise.all([api("/api/alunos"), api("/api/livros")]);
  state.alunos = alunos; state.livros = livros;
  const disponiveis = livros.filter((book) => book.quantidade_disponivel > 0);
  if (!alunos.length) { showToast("Cadastre pelo menos um aluno antes de registrar um empréstimo.", true); return; }
  if (!disponiveis.length) { showToast("Não há livros disponíveis para empréstimo.", true); return; }
  const due = new Date(); due.setDate(due.getDate() + 14);
  const localDue = new Date(due.getTime() - due.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  showModal({
    eyebrow: "CONTROLE DE CIRCULAÇÃO", title: "Registrar empréstimo", submitText: "Confirmar empréstimo",
    fields: [
      { name: "aluno_id", label: "Aluno", type: "select", required: true, full: true, options: alunos.map((a) => ({ value: a.id, label: `${a.nome} — ${a.turma}` })) },
      { name: "livro_id", label: "Livro disponível", type: "select", required: true, full: true, options: disponiveis.map((b) => ({ value: b.id, label: `${b.titulo} (${b.quantidade_disponivel} disponível(is))` })) },
      { name: "data_devolucao_prevista", label: "Data prevista para devolução", type: "date", value: localDue, required: true, min: todayISO(), full: true }
    ],
    onSubmit: async (values) => {
      values.aluno_id = Number(values.aluno_id); values.livro_id = Number(values.livro_id);
      await api("/api/emprestimos", { method: "POST", body: JSON.stringify(values) });
      closeModal(); showToast("Empréstimo registrado com sucesso."); await renderPage();
    }
  });
}

async function handleAction(action, id) {
  try {
    if (action === "new-book") return openBookModal();
    if (action === "new-student") return openStudentModal();
    if (action === "new-loan") return await openLoanModal();
    if (action === "edit-book") return openBookModal(state.livros.find((item) => item.id === Number(id)));
    if (action === "edit-student") return openStudentModal(state.alunos.find((item) => item.id === Number(id)));
    if (action === "delete-book") {
      if (!confirm("Deseja realmente excluir este livro?")) return;
      await api(`/api/livros/${id}`, { method: "DELETE" }); showToast("Livro excluído."); return renderPage();
    }
    if (action === "delete-student") {
      if (!confirm("Deseja realmente excluir este aluno?")) return;
      await api(`/api/alunos/${id}`, { method: "DELETE" }); showToast("Aluno excluído."); return renderPage();
    }
    if (action === "return-loan") {
      if (!confirm("Confirmar a devolução deste livro?")) return;
      await api(`/api/emprestimos/${id}/devolver`, { method: "PATCH" }); showToast("Devolução registrada. O estoque foi atualizado."); return renderPage();
    }
  } catch (error) {
    showToast(error.message, true);
  }
}

// Eventos da navegação e dos botões da interface.
document.addEventListener("click", (event) => {
  const pageButton = event.target.closest("[data-page]");
  if (pageButton) { setPage(pageButton.dataset.page); return; }
  const actionButton = event.target.closest("[data-action]");
  if (actionButton) handleAction(actionButton.dataset.action, actionButton.dataset.id);
});

$("#mobileMenu").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
$("#closeModal").addEventListener("click", closeModal);
$("#cancelModal").addEventListener("click", closeModal);
$("#modalBackdrop").addEventListener("click", (event) => { if (event.target.id === "modalBackdrop") closeModal(); });
document.addEventListener("keydown", (event) => { if (event.key === "Escape" && !$("#modalBackdrop").hidden) closeModal(); });

$("#modalForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!modalSubmitHandler) return;
  const saveButton = $("#saveButton");
  saveButton.disabled = true; saveButton.textContent = "Salvando...";
  const values = Object.fromEntries(new FormData(event.currentTarget).entries());
  try { await modalSubmitHandler(values); }
  catch (error) { showToast(error.message, true); }
  finally { saveButton.disabled = false; saveButton.textContent = "Salvar registro"; }
});

const now = new Date();
$("#todayLabel").textContent = now.toLocaleDateString("pt-BR", { weekday: "short", day: "2-digit", month: "short", year: "numeric" });
renderPage();
