from flask import Flask, jsonify, render_template, request
from config import Config
from routes.alunos import bp_alunos
from routes.livros import bp_livros
from routes.emprestimos import bp_emprestimos
from routes.dashboard import bp_dashboard


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    app.register_blueprint(bp_alunos)
    app.register_blueprint(bp_livros)
    app.register_blueprint(bp_emprestimos)
    app.register_blueprint(bp_dashboard)

    @app.get("/")
    def inicio():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "aplicacao": "Biblioteca Escolar"})

    @app.errorhandler(404)
    def nao_encontrado(error):
        if request.path.startswith("/api/"):
            return jsonify({"erro": "Rota não encontrada."}), 404
        return error

    return app

app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=Config.DEBUG)
